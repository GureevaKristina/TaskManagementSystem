﻿namespace TaskManagementSystem.Models
{
    public enum TaskStatus
    {
        NotStarted, 
        InProgress,
        Completed
    }
}